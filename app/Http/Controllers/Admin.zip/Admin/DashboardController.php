<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Resep;
use App\Models\Kategori;
use App\Models\User;
use App\Models\Ulasan;

class DashboardController extends Controller
{
    public function index()
    {
        if (auth()->user()->role === 'user') { abort(403); }

        $totalResep    = Resep::count();
        $totalKategori = Kategori::count();
        $totalUser     = User::where('role', 'user')->count();
        $totalKomentar = Ulasan::count();
        $reseps        = Resep::with('kategori')->latest()->get();

        return view('admin.dashboard', compact('totalResep', 'totalKategori', 'totalUser', 'totalKomentar', 'reseps'));
    }

    public function users()
    {
        // Hanya Superadmin yang bisa buka
        if (auth()->user()->role !== 'superadmin') {
            abort(403, 'Hanya Super Admin yang bisa mengakses halaman ini.');
        }

        $users = User::orderBy('id')->get();
        return view('admin.users', compact('users'));
    }
}